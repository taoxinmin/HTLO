function [ pop ischanged]= addls(pop,pLsize,vTsize,vCsize,vOsize)
%pop      必须是 1*N；当前需要add的解
%CoverM,  覆盖矩阵，N*N
%PB,      距离矩阵,N*N
%pLsize   快ischanged递柜的个数
%vTsize   必须访问的客户的个数
%vCsize   必须覆盖的客户的个数
%vOsize   可选的客户的个数

		N = size(pop,2);
		if 1+pLsize+vTsize+vCsize+vOsize ~= N
			error('Ugly error!!!'); 
		end
		ischanged = 0;
	
		%对可选的客户中被分配给PL的节点，放到route上
		
		%对可选的客户进行随机选取
		notonrouteidx = find(pop(1,1+pLsize+vTsize+vCsize+1:end)~=0);
		if isempty(notonrouteidx)
			ischanged = 0;
			return;
		end
		
		%随机选择一个notonroute的客户点
		lennotonroute = length(notonrouteidx);
		selectnotonrouteidxtmp = randperm(lennotonroute,1);
		selectnotonrouteidx = 1+pLsize+vTsize+vCsize+notonrouteidx(selectnotonrouteidxtmp);
		
		%令其在route上
		pop(1,selectnotonrouteidx) = 0; 
		ischanged = 1;		
				
		%修复每一个解，主要是针对PL的，根据上面的选择情况
		pop(1,1+1:1+pLsize) = -1;%以防万一，再次置为-1
		Coveredbyi = pop(1,1+pLsize+vTsize+1:end);%所有的覆盖的和可选的客户的选择情况
		Cset =  unique(Coveredbyi);%独一无二的值
		Cset(Cset==0)=[];%去掉0
		if ~isempty(Cset)
			pop(1,Cset) = 0;
		end

		
		
	
	
		
