function [ pop ischanged]= dropls(pop,CoverM,PB,pLsize,vTsize,vCsize,vOsize)
%pop     必须是 1*N；当前需要drop的解
%CoverM, 覆盖矩阵，N*N
%PB,    距离矩阵,N*N
%pLsize   快ischanged递柜的个数
%vTsize   必须访问的客户的个数
%vCsize   必须覆盖的客户的个数
%vOsize   可选的客户的个数

	N = size(pop,2);
	if 1+pLsize+vTsize+vCsize+vOsize ~= N
		error('Ugly error!!!'); 
	end
	ischanged = 0;
	
	%drop的前提：是把当前解中，可选客户中在route上的客户
	%且能覆盖它的PL节点至少有一个在route上，
	%drop掉，然后在能覆盖它的在route上的PL节点找一个最近的节点，赋值给它
	%
		%对可选的客户进行随机选取
		onrouteidx = find(pop(1,1+pLsize+vTsize+vCsize+1:end)==0);
		if isempty(onrouteidx)
			ischanged = 0;
			return;
		end
		
		%寻找所有在route上的PL节点
		Sonroute = find(pop(1, 1+1:1+pLsize)==0);
		Sonroute = Sonroute+1;%因为depot编码1，占一个；应为PL编码从2开始，都需要加1
		if isempty(Sonroute)%没有PL节点在route上面
			ischanged = 0;
			return;
		end
			
			
		lenonroute = length(onrouteidx);
		selectonrouteidxtmp = randperm(lenonroute);
		selectonrouteidxset = 1+pLsize+vTsize+vCsize+onrouteidx(selectonrouteidxtmp);
		%因为可选客户的编码是从1+pLsize+vTsize+vCsize开始的，
		%都需要加1+pLsize+vTsize+vCsize
		%selectonrouteidxset是随机排序在route上的可选客户的结果
		for j = 1:lenonroute
				%随机选择一个onroute的客户点
			selectonrouteidx = selectonrouteidxset(j);
			%判断onroute的客户点,PL点从2开始，第一个是depot
			Stemp = CoverM( 1+1:1+pLsize,selectonrouteidx);
		
			S = find(Stemp==1);
			%%能够覆盖selectonrouteidx的所有PL节点
			Ssize = length(S);
			S = S+1;%PL节点从2开始的，depot是1
			if Ssize == 0
				error('Ugly error!!! should be visited why to be optional?');
			end
			
			
			%寻找即能覆盖当前selectonrouteidx客户又在route上的PL节点
			SS = intersect(S,Sonroute);
			%发现覆盖当前selectonrouteidx客户的PL节点集合中最近的节点
			if ~isempty(SS)
			
				[dummy,sortedidx] = sort(PB(SS,selectonrouteidx));
				nearestPLidx = SS(sortedidx(1));
				pop(1,selectonrouteidx) = nearestPLidx; 
				ischanged = 1;
				
				%修复每一个解，主要是针对PL的，根据上面的选择情况
				pop(1,1+1:1+pLsize) = -1;%以防万一，再次置为-1
				Coveredbyi = pop(1,1+pLsize+vTsize+1:end);%所有的覆盖的和可选的客户的选择情况
				Cset =  unique(Coveredbyi);%独一无二的值
				Cset(Cset==0)=[];%去掉0
				if ~isempty(Cset)
					pop(1,Cset) = 0;
				end
				break;
				
			end	
		end
		
		
	
	
		
