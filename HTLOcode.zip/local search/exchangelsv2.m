function [ pop ischanged]= exchangelsv2(pop,CoverM,PB,pLsize,vTsize,vCsize,vOsize)
%pop      必须是 1*N；当前需要exchange的解
%CoverM,  覆盖矩阵，N*N
%PB,      距离矩阵,N*N
%pLsize   快递柜的个数
%vTsize   必须访问的客户的个数
%vCsize   必须覆盖的客户的个数
%vOsize   可选的客户的个数

		N = size(pop,2);
		if 1+pLsize+vTsize+vCsize+vOsize ~= N
			error('Ugly error!!!'); 
		end
		ischanged = 0;
	
	%exchange1操作，是随机选择一个在route上的可选客户
	%选择一个不在route上的可选客户，这个不在route上的
	%可选客户必须和上一个可选客户在同一个PL上，且这个PL节点在route上
	%然后交换：这个节点被PL节点覆盖，然后另一个节点在route上
	
		%对可选的在route上的客户进行随机选取
		onrouteidx = find(pop(1,1+pLsize+vTsize+vCsize+1:end)==0);
		if isempty(onrouteidx)
			ischanged = 0;
			return;
		end
		
		%对可选的不在route上的客户进行随机选取
		onnotrouteidx = find(pop(1,1+pLsize+vTsize+vCsize+1:end)~=0);
		if isempty(onnotrouteidx)
			ischanged = 0;
			return;
		end
		
		%对不在route上的可选节点随机排序
		lennotonroute = length(onnotrouteidx);
		selectnotonrouteidxtmp = randperm(lennotonroute);
		selectnotonrouteidxset = 1+pLsize+vTsize+vCsize+onnotrouteidx(selectnotonrouteidxtmp);
		
		%对在route上的可选节点随机排序
		lenonroute = length(onrouteidx);
		selectonrouteidxtmp = randperm(lenonroute);
		selectonrouteidxset = 1+pLsize+vTsize+vCsize+onrouteidx(selectonrouteidxtmp);
		
		
		%%在route上的PL节点集合
		Sonroute = find(pop(1, 1+1:1+pLsize)==0);
		Sonroute = Sonroute+1;%PL编码从2开始，depot编码为1
		if isempty(Sonroute)
			ischanged = 0;
			return;	
		end
		
		
		for j = 1:lenonroute
			
			%随机选择一个onroute的客户点
			selectonrouteidx = selectonrouteidxset(j);
			%判断onroute的客户点,PL点从2开始，第一个是depot
			Stemp = CoverM( 1+1:1+pLsize,selectonrouteidx);
		
			S = find(Stemp==1);
			%%能够覆盖selectonrouteidx的所有PL节点
			Ssize = length(S);
			S = S+1;%PL节点从2开始的，depot是1
			if Ssize == 0
				error('Ugly error!!! should be visited why to be optional?');
			end
			
			
			%寻找即能覆盖当前selectonrouteidx客户又在route上的PL节点
			SS = intersect(S,Sonroute);
			
			%发现覆盖当前selectonrouteidx客户的PL节点集合中最近的节点
			if ~isempty(SS)
			
				%离当前selectonrouteidx客户最近的又
				%不在route上的PL节点,按距离排序
				[dummy,sortedidx] = sort(PB(SS,selectonrouteidx));
				nearestPLidx = SS(sortedidx);
				
				%寻找能同时覆盖任何一个不在route上的可选节点
				for k = 1: length(nearestPLidx)
					
					%寻找能被nearestPLidx(k)覆盖的不在route上的可选节点
					SStemp = CoverM(nearestPLidx(k),selectnotonrouteidxset);
					coveredbykidx = find(SStemp==1);
					coveredbykidx = 1+pLsize+vTsize+vCsize+coveredbykidx;
					%可选节点从1+pLsize+vTsize+vCsize开始的
					
					if ~isempty(coveredbykidx)
						rndcoveredbykidx = randperm(length(coveredbykidx),1);
						exhcangeID = coveredbykidx(rndcoveredbykidx);
						pop(1,exhcangeID) = 0; 
						pop(1,selectonrouteidx) = nearestPLidx(k); 
						ischanged = 1;
						break;
					end
					
				end
							
			end
			
		end