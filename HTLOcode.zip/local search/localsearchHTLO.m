function localsearchHTLO(pop,result,CoverM,PB,pLsize,vTsize,vCsize,vOsize,maxcount)	
%pop      必须是 1*N；当前需要add的解
%result   是pop的适应值，scalar量
%CoverM,  覆盖矩阵，N*N
%PB,      距离矩阵,N*N
%pLsize   快ischanged递柜的个数
%vTsize   必须访问的客户的个数
%vCsize   必须覆盖的客户的个数
%vOsize   可选的客户的个数
%maxcount 每个局部邻域执行的最大次数
	global MaxOperators;
	global wOperators; % weights of the operators
	global OperatorUseTimes;%The number of times the operator has been used
	global OperatorScore;%the score of operators
	global rho;
	
	global gbest_val;
	global gbest_secondlastgbest;
	global gbest_pop;
	
	maxcount   = vOsize;

	%disp('local search!!!!!!!!!!!!!!!!!!');
	iter = 1;
	l = 1;
	l_max = 4; %贪心邻域操作次数
	while l <= l_max
		iter = iter+1;
					
		[selectOpId] = selectOperator(wOperators);
		switch selectOpId
		case 1
			[ newpop newresult secondlastgbest]= ...
			   N1_addls(pop,result,PB,pLsize,vTsize,vCsize,vOsize,maxcount);
		case 2
			[ newpop newresult secondlastgbest]= ...
			   N2_dropls(pop,result,CoverM,PB,pLsize,vTsize,vCsize,vOsize,maxcount);
		case 3
			[newpop newresult secondlastgbest ]= ...
   			   N3_ex1ls(pop,result,CoverM,PB,pLsize,vTsize,vCsize,vOsize,maxcount);
		case 4
			[newpop newresult secondlastgbest ]= ...
   			   N4_ex2ls(pop,result,CoverM,PB,pLsize,vTsize,vCsize,vOsize,maxcount);
		end
		OperatorUseTimes(selectOpId) = OperatorUseTimes(selectOpId)+1;			
			
		if newresult < result
			%更新当前解
			pop = newpop;
			result = newresult;
		    if newresult < gbest_val
			%更新最优解
				gbest_pop = newpop;
				gbest_val = newresult;
				gbest_secondlastgbest  = secondlastgbest;
				OperatorScore(selectOpId) =OperatorScore(selectOpId)+ 1.5;
				
				%update the score of the operators
			else
				OperatorScore(selectOpId) = OperatorScore(selectOpId)+1.2;
            end  
			l = 1;
		else
			l = l + 1;
		end	
		
		wOperators(selectOpId) = wOperators(selectOpId) * rho + (1 - rho) * ...
			(OperatorScore(selectOpId) / OperatorUseTimes(selectOpId));
		
			%显示
		%if (rem(iter, 3) == 0)
		%	disp(sprintf('%4d\t\t\t%5d\t\t\t%5d', iter, newresult, gbest_val));
		%end
	end
		
		
	%%%%%%%%%%%%Add操作%%%%%%%%%%%%%%%%%%%%%%%%%%%%%	
function [new_pop result_new secondlastgbest]= N1_addls(...
			curpop,result,PB,pLsize,vTsize,vCsize,vOsize,maxcount)
	%%%给你maxcount次机会去寻找邻域
	count = 0;
	
	new_pop = curpop; 
	result_new = result;
	
	while count < maxcount
		[ new_pop ischanged]= addls(curpop,pLsize,vTsize,vCsize,vOsize);
		if ischanged == 1
			[result_new,secondlastgbest,secondlastfgbest]= calObjfunc(new_pop,PB,pLsize);
			if result_new >= result
				count = count + 1;
			else
				break;
			end	
		else
			break;
		end
		
	end
	
	%%%%%%%%%%%%Drop操作%%%%%%%%%%%%%%%%%%%%%%%%%%%%%	
function [new_pop result_new secondlastgbest]= N2_dropls(curpop,result,CoverM,PB,pLsize,vTsize,vCsize,vOsize,maxcount)
	%%%给你maxcount次机会去寻找邻域
	count = 0;
	
	new_pop = curpop; 
	result_new = result;
	
	
	while count < maxcount
		
		[ new_pop ischanged]= dropls(curpop,CoverM,PB,pLsize,vTsize,vCsize,vOsize);
		if ischanged == 1
			[result_new,secondlastgbest,secondlastfgbest]= calObjfunc(new_pop,PB,pLsize);
			if result_new >= result
				count = count + 1;
			else
				break;
			end	
		else
			break;
		end
		
	end
	
	
	%%%%%%%%%%%%Exchange1操作%%%%%%%%%%%%%%%%%%%%%%%%%%%%%	
function [new_pop result_new secondlastgbest]= N3_ex1ls(curpop,result,CoverM,PB,pLsize,vTsize,vCsize,vOsize,maxcount)
	%%%给你maxcount次机会去寻找邻域
	count = 0;
	new_pop = curpop; 
	result_new = result;
	
	while count < maxcount
		
		[ new_pop ischanged]= exchangelsv1(curpop,CoverM,PB,pLsize,vTsize,vCsize,vOsize);
		if ischanged == 1
			[result_new,secondlastgbest,secondlastfgbest]= calObjfunc(new_pop,PB,pLsize);
			if result_new >= result
				count = count + 1;
			else
				break;
			end	
		else
			break;
		end
		
	end	
	
%%%%%%%%%%%%Exchange2操作%%%%%%%%%%%%%%%%%%%%%%%%%%%%%	
function [new_pop result_new secondlastgbest]= N4_ex2ls(curpop,result,CoverM,PB,pLsize,vTsize,vCsize,vOsize,maxcount)
	%%%给你maxcount次机会去寻找邻域
	count = 0;
	new_pop = curpop; 
	result_new = result;
	
	while count < maxcount
		[ new_pop ischanged]= exchangelsv2(curpop,CoverM,PB,pLsize,vTsize,vCsize,vOsize);
		if ischanged == 1
			[result_new,secondlastgbest,secondlastfgbest]= calObjfunc(new_pop,PB,pLsize);
			if result_new >= result
				count = count + 1;
			else
				break;
			end	
		else
			break;
		end
		
	end		
	