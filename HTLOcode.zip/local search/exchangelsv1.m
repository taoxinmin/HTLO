function [ pop ischanged]= exchangelsv1(pop,CoverM,PB,pLsize,vTsize,vCsize,vOsize)
%pop      必须是 1*N；当前需要exchange的解
%CoverM,  覆盖矩阵，N*N
%PB,      距离矩阵,N*N
%pLsize   快ischanged递柜的个数
%vTsize   必须访问的客户的个数
%vCsize   必须覆盖的客户的个数
%vOsize   可选的客户的个数

		N = size(pop,2);
		if 1+pLsize+vTsize+vCsize+vOsize ~= N
			error('Ugly error!!!'); 
		end
		ischanged = 0;
		
		%exchange1操作，是随机选择一个在route上的可选客户
		%选择一个不在route上的PL节点，这个节点必须能cover这个可选客户，
		%然后交换：这个节点被PL节点覆盖，然后这个PL节点在route上
	
	
		%对可选的在route上的客户进行随机选取
		onrouteidx = find(pop(1,1+pLsize+vTsize+vCsize+1:end)==0);
		if isempty(onrouteidx)
			ischanged = 0;
			return;
		end
		
		%%没有在route上的PL节点集合
		Snotonroute = find(pop(1, 1+1:1+pLsize)==-1);
		Snotonroute = Snotonroute+1;%PL编码从2开始，depot编码为1
		if isempty(Snotonroute)
			ischanged = 0;
			return;	
		end
			
			
		lenonroute = length(onrouteidx);
		selectonrouteidxtmp = randperm(lenonroute);
		selectonrouteidxset = 1+pLsize+vTsize+vCsize+onrouteidx(selectonrouteidxtmp);
		
		for j = 1:lenonroute
			
			%随机选择一个onroute的客户点
			selectonrouteidx = selectonrouteidxset(j);
			%判断onroute的客户点,PL点从2开始，第一个是depot
			Stemp = CoverM( 1+1:1+pLsize,selectonrouteidx);
		
			S = find(Stemp==1);
			%%能够覆盖selectonrouteidx的所有PL节点
			Ssize = length(S);
			S = S+1;%PL节点从2开始的，depot是1
			if Ssize == 0
				error('Ugly error!!! should be visited why to be optional?');
			end
			
			
			%寻找即能覆盖当前selectonrouteidx客户又不在route上的PL节点
			SS = intersect(S,Snotonroute);
			%发现覆盖当前selectonrouteidx客户的PL节点集合中最近的节点
			if ~isempty(SS)
			
				%离当前selectonrouteidx客户最近的又不在route上的PL节点
				[dummy,sortedidx] = sort(PB(SS,selectonrouteidx));
				nearestPLidx = SS(sortedidx(1));
				
				pop(1,selectonrouteidx) = nearestPLidx; 
				pop(1,nearestPLidx) = 0; 
				ischanged = 1;
				break;
				
			end
			
		end
		
		
	
	
		
