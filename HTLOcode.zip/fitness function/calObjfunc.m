function  [totalcost,secondlastgbest,secondlastfgbest]= calObjfunc(pop,PB,pLsize)

%%%	pop 是 1*N的行向量
%PB,    距离矩阵,N*N
%pLsize   快递柜的个数


	global ci;
	%当前解在route上的节点编号
	onrouteverID = find (pop==0);
	arc = PB(onrouteverID,onrouteverID);
	%二层规划，TSP问题
	[gbest fgbest]= TSP_alnsVNS(arc);
	
	secondlastgbest  = onrouteverID(gbest);
	secondlastfgbest = fgbest;
	%secondlastgbest = [];
	%secondlastfgbest = 0;
	%%所有被覆盖的客户数
	totalcost = ci*sum(pop(1,1+pLsize+1:end)~=0) + secondlastfgbest;
	%totalcost = ci*sum(pop(1,1+pLsize+1:end)~=0);
	