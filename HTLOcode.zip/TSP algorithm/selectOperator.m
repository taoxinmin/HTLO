function [selectOpId] = selectOperator(weight)
%%%归一化
weight = weight/sum(weight);
c_sum = cumsum(weight);
select = rand(1,1);
selectOpId = min(find(c_sum>=select));    