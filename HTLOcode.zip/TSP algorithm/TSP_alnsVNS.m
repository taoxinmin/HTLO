function [gbest fgbest]= TSP_alnsVNS(arc,maxcount,route)
% 输入route, arc,maxcount—路径，距离矩阵，最大迭代次数
	if nargin > 2
		if (length(route) > size(arc,1)+1)...
		| (length(route) < size(arc,1))
			error('ugly,长度不匹配');
		end
		
		if length(route) == size(arc,1)+1
			if (route(end)==route(1))
				route = route(1:end-1);
			else
				error('ugly,route内容不对');	
			end
		end
	else
		route  = randperm(size(arc,1));
	end
	
	%disp(sprintf('Iterations\t\t\t local search No \t\t\t fbestroute'));
	M = length(route);
	f_route = CalDist(arc,route);
	iter = 0;% 控制循环显示
	
	
	%%%需要调整的参数
	maxshaking = 1;%5*size(arc,1);
	maxcount = 100;%*size(arc,1);
	
	MaxOperators = 4;
	wOperators = ones(1,MaxOperators); % weights of the operators
	OperatorUseTimes = zeros(1,MaxOperators);%The number of times the operator has been used
	OperatorScore = ones(1,MaxOperators);%the score of operators
	rho = 0.6;
	
	gbest = route;
	fgbest = f_route;
	shaking=1;
	
	while shaking <= maxshaking
		%shaking procedure
		[route]=MPXshakingOpt(gbest);
		f_route = CalDist(arc,route);
		%disp(sprintf('shaking!!!!!!\t\t\t%d',shaking));
		%[route]=crossoverShakingOpt(route,randperm(size(arc,1)));
		%route  = randperm(size(arc,1));
		updategbestflag = 0;
		l = 1;
		l_max = 4; %贪心邻域操作次数
		while l <= l_max
			iter = iter+1;
			%findbestsolution
			
			[selectOpId] = selectOperator(wOperators);
			switch selectOpId
			case 1
				[new_route f_route_new]= N1_2opt(arc,route,f_route,maxcount);
			case 2
				[new_route f_route_new]= N2_3opt(arc,route,f_route,maxcount);
			case 3
				[new_route f_route_new]= N3_Insert(arc,route,f_route,maxcount);
			case 4
				[new_route f_route_new]= N4_Swap(arc,route,f_route,maxcount);
			end
			OperatorUseTimes(selectOpId) = OperatorUseTimes(selectOpId)+1;			
			
			if f_route_new < f_route
				%更新当前解
				route = new_route;
				f_route = f_route_new;
		        if f_route_new < fgbest
					%更新最优解
                    gbest = new_route;
					fgbest = f_route_new;
                    OperatorScore(selectOpId) =OperatorScore(selectOpId)+ 1.5;
					updategbestflag = 1;
					%update the score of the operators
                else
                     OperatorScore(selectOpId) = OperatorScore(selectOpId)+1.2;
                end  
				l = 1;
			else
				l = l + 1;
			end	
			wOperators(selectOpId) = wOperators(selectOpId) * rho + (1 - rho) * ...
               (OperatorScore(selectOpId) / OperatorUseTimes(selectOpId));
		
			%显示
			%if (rem(iter, 3) == 0)
			%	disp(sprintf('%4d\t\t\t%5d\t\t\t%5d', iter, f_route,fgbest ));
			%end
		end
		%保优策略
		if updategbestflag==1
			shaking = 1;
		else
			shaking = shaking + 1;
		end	
	end
	
function costsum = CalDist(arc,initroute)	
    costsum = 0;
	for i =1:length(initroute)-1
		costsum = costsum + arc(initroute(i),initroute(i+1));
	end
	costsum = costsum + arc(initroute(end),initroute(1));

	
%%%%%%%%%%%%2opt操作%%%%%%%%%%%%%%%%%%%%%%%%%%%%%	
function [new_route f_route_new]= N1_2opt(arc,curroute,f_route,maxcount)
	%%%给你maxcount次机会去寻找邻域
	count = 0;
	
	while count < maxcount
		new_route = F2opt(curroute);
		f_route_new = CalDist(arc, new_route);
		if f_route_new >= f_route
			count = count + 1;
		else
			break;
		end	
	end

%%%%%%%%%%%%N2_3opt操作%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [new_route f_route_new]= N2_3opt(arc,curroute,f_route,maxcount)
	%%%给你maxcount次机会去寻找邻域
	count = 0;
	
	while count < maxcount
		opt = randperm(7,1);
		F3 = ['new_route = F3opt',num2str(opt),'(curroute);'];
		%new_route = F3opt1(curroute);
		eval(F3);
		f_route_new = CalDist(arc, new_route);
		if f_route_new >= f_route
			count = count + 1;
		else
			break;
		end	
	end		
	
	%%%%%%%%%%%%Insert操作%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [new_route f_route_new]= N3_Insert(arc,curroute,f_route,maxcount)
	%%%给你maxcount次机会去寻找邻域
	count = 0;
	
	while count < maxcount
		new_route = Insertopt(curroute);
		f_route_new = CalDist(arc, new_route);
		if f_route_new >= f_route
			count = count + 1;
		else
			break;
		end	
	end
	
%%%%%%%%%%%%Insert操作%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [new_route f_route_new]= N4_Swap(arc,curroute,f_route,maxcount)
	%%%给你maxcount次机会去寻找邻域
	count = 0;
	
	while count < maxcount
		new_route = Swapopt(curroute);
		f_route_new = CalDist(arc, new_route);
		if f_route_new >= f_route
			count = count + 1;
		else
			break;
		end	
	end	
