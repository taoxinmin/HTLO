   function E = L2_dist(A,B)
	% E = L2_dist(A,B)
%
%    A - (MxD) matrix 
%    B - (NxD) matrix
% 
% Returns:
%    E - (MxN) Euclidean distances between vectors in A and B

    x = A ;
	xsup = B;
    ps = x*xsup'; 
    %x=[x1,x2,x3...],横向特征向量，每一个特征向量计算得到的是一个标量，行数=x的行数（样本数），列数=xsup的列数（xsup的个数）
    [nps,pps]=size(ps);%nps是样本个数，pps就是xsup个数
    normx = sum(x.^2,2);%每一个向量中的特征值.2相加
    normxsup = sum(xsup.^2,2);%每一个向量中的特征值.2相加
    ps = -2*ps + repmat(normx,1,pps) + repmat(normxsup',nps,1) ; 
	E=sqrt(ps);
    %得到的是行数为x的行数个数，列为xsup的个数。
	
	
	