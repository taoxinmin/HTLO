    function [newdata,newpd,CoverIdx,PLsize,VTsize,Vcsize,Vosize] ...
            	= generateCoverdata(data,CL,alpha,beta)
%%  input：data N*dim,dim是2个，坐标（x,y)坐标    
%%  CL：是最近邻的个数
%%  alpha，beta：是参数比例

	test = data;
	M = size(test,1);
	N = size(data,1);
	pd = L2_dist(test,data);
	k_nNum = CL;

	%
	%    A - (MxD) matrix 
	%    B - (NxD) matrix
	% 
	% Returns:
	%    E - (MxN) Euclidean distances between vectors in A and B
	
	PLsize = floor(alpha*(N-1));%第一个节点是depot
	PLdata = data(1+1:1+PLsize,:); 
	startidofcustomer = 1+PLsize;
	
	vAsize = N-1-PLsize;
	
	%生成Cover矩阵,
	CoverIdx = eye(N);
	for i =1:PLsize
		tempdist = pd (1+i,startidofcustomer+1:end); 
		%每个PL节点与客户节点的距离，注意PL从2开始的，第一个是depot
		[tmp,id]=sort(tempdist);
		in_id=startidofcustomer+id(1:k_nNum);%最近邻下标
		CoverIdx(1+i,in_id) = 1;
		CoverIdx(in_id,1+i) = 1;
	end
	
	%寻找没有被覆盖的customer点和剩余的customer点
	vT = [];
	subCovermatrix = CoverIdx(1+1:1+PLsize,startidofcustomer+1:end);
	customerID = startidofcustomer+1:N;
	
	for i = 1:size(subCovermatrix,2) %%客户数
		if sum(subCovermatrix(:,i)) == 0 %%没有被PL覆盖
			vT = [vT,i+startidofcustomer];
			customerID(find(customerID==i+startidofcustomer)) =[];
		end
	end
    
	if isempty(vT)
		disp('vT =0;Please decrease the number of CL! no customer must be visited');
	end
	
	VTsize = length(vT);
	
	if (vAsize-VTsize) ~= length(customerID)
		error('ugly error! ');
	end
	
	%剩余的customer点的前beta个是必须覆盖的点
	Vcsize = floor(beta*(vAsize-VTsize));
	Vc     = customerID(1:Vcsize);
	
	Vosize = vAsize-VTsize-Vcsize;
	Vo     = customerID(Vcsize+1:end);
	
	
	newdata = [data(1,:); data(1+1:PLsize+1,:);...
	           data(vT,:);data(Vc,:);data(Vo,:)];
	newpd = L2_dist(newdata,newdata);		   
	if size(newdata,1) ~=N
		error('Ugly error!');
	end
	
	%重新生成Cover矩阵
	%	
	%生成Cover矩阵,N*N
	
	CoverIdx = eye(N);
	for i =1:PLsize
		tempdist = newpd (1+i,startidofcustomer+1:end);
		[tmp,id]=sort(tempdist);
		in_id=startidofcustomer+id(1:k_nNum);%最近邻下标
		CoverIdx(1+i,in_id) = 1;
		CoverIdx(in_id,1+i) = 1;
	end
	%CoverIdx = CoverIdx(2:end,:); 
	%CoverIdx = CoverIdx(:,2:end);
	
	if N ~= 1+PLsize+VTsize+Vcsize+Vosize
		error('N~=1+PLsize+VTsize+Vcsize+Vosize!!');
	end