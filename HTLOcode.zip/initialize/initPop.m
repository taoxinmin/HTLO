function [ pop ]= initPop(SwarmSize,CoverM,PB,pLsize,vTsize,vCsize,vOsize)
%CoverM, 覆盖矩阵，N*N，N是节点的个数
%PB,    距离矩阵,N*N
%pLsize   快递柜的个数
%vTsize   必须访问的客户的个数
%vCsize   必须覆盖的客户的个数
%vOsize   可选的客户的个数
	
	N = size(PB,1);
	if 1+pLsize+vTsize+vCsize+vOsize ~= N
		error('Ugly error!!!'); 
	end
	
	%0表示必须访问,PL的所有节点置为-1，表示不在route访问之列，根据后面客户的选择情况再设置
	pop = zeros(SwarmSize,N);
	pop(:,1+1:pLsize+1) = -1*ones(SwarmSize,pLsize);
	
	%对必须覆盖的客户进行随机选取
	for i = 1+pLsize+vTsize+1:1+pLsize+vTsize+vCsize
		
		Stemp = CoverM( 1+1:1+pLsize,i);%客户i被PL的覆盖情况
		S = find(Stemp==1);%等于1表示被覆盖
		S = S+1;%因为PL编码从2开始，都需要加1
		
		Ssize = length(S);
		if Ssize == 0
			error('Ugly error!!! should be visited why covered?');
		end
		%%%矩阵形式，赋值	
		selectedSindx = floor(rand(SwarmSize, 1) * Ssize)+1;
		pop(:,i) = S(selectedSindx); %直接一次性对所有种群的个体的i节点赋值
			
	end


	%对可选的客户进行随机选取
	for i = 1+pLsize+vTsize+vCsize+1:1+pLsize+vTsize+vCsize+vOsize
		
		Stemp = CoverM( 1+1:1+pLsize,i);%客户i被PL的覆盖情况
		S = find(Stemp==1);%等于1表示被覆盖
		S = S+1;%因为PL编码从2开始，都需要加1
		Ssize = length(S);
		if Ssize == 0
			error('Ugly error!!! should be visited why to be optional?');
		end
		
		for j = 1: SwarmSize  
		
			if rand < 0.5   %我觉得应该是visited然后再是covered，选谁cover它
				pop(j,i) = 0;
			else	
				selectedSindx = floor(rand(1, 1) * Ssize)+1;
				pop(j,i) = S(selectedSindx); 
			end
			
		end
		
	end
	
	%修复每一个解，主要是针对PL的，根据上面的选择情况
	for j = 1: SwarmSize  
			
		pop(j,1+1:1+pLsize) = -1;%以防万一，再次置为-1
		Coveredbyi = pop(j,1+pLsize+vTsize+1:end);%所有的覆盖的和可选的客户的选择情况
		Cset =  unique(Coveredbyi);%独一无二的值
		Cset(Cset==0)=[];%去掉0
		if ~isempty(Cset)
			pop(j,Cset) = 0;
		end
		
	end