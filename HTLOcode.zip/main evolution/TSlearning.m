function [pop]= TSlearning(pop,Pt,gbest,pLsize,vTsize,vCsize,vOsize)
%%pop  是swarmSize*N，矩阵
%%Pt   是SwarmSize*1 向量，表示每个粒子的学习概率
%pLsize   快递柜的个数
%vTsize   必须访问的客户的个数
%vCsize   必须覆盖的客户的个数
%vOsize   可选的客户的个数


	[popsize,n] = size(pop);
	if n ~= 1+pLsize+vTsize+vCsize+vOsize
		error('Ugly error!n ~= 1+pLsize+vTsize+vCsize+vOsize');
	end
	
	
	%只需要对Vc和Vo的客户进行进化crossover
	subpop = pop(:,1+pLsize+vTsize+1:end);
	[popsize,n] = size(subpop);
	if n ~= vCsize+vOsize
		error('Ugly error!n ~= vCsize+vOsize');
	end
	
	
	%%%%构造vi%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	vi = gbest(ones(popsize,1),:);
	%只需要对Vc和Vo的gbest相应位置进行进化crossover
	subvi = vi(:,1+pLsize+vTsize+1:end);
	
	
	% == == == == = Crossover == == == == =
    mask = rand(popsize, n) > Pt(:, ones(1, n)); 
	% mask is used to indicate which elements of ui comes from the (self)
    %mask ==1 表示该位置来至自己，而不是来至gbest（其他）
	rows = (1 : popsize)'; 
	cols = floor(rand(popsize, 1) * n)+1; 
	% choose one position where the element of ui doesn't come from the parent
    jrand = sub2ind([popsize n], rows, cols); mask(jrand) = false;
	%强制至少某个位置不能来至自己，防止没有一个位置向别人（gbest）学习
    ui = subvi; ui(mask) = subpop(mask);
	
	
	pop(:,1+pLsize+vTsize+1:end)=ui;
	
	%修复每一个解，主要是针对PL的，根据上面的选择情况
	for j = 1: popsize  
			
			pop(j,1+1:1+pLsize) = -1;%以防万一，再次置为-1
			Coveredbyi = pop(j,1+pLsize+vTsize+1:end);%所有的覆盖的和可选的客户的选择情况
			Cset =  unique(Coveredbyi);%独一无二的值
			Cset(Cset==0)=[];%去掉0
			if ~isempty(Cset)
				pop(j,Cset) = 0;
			end
	end