function [pop]= CLSlearning(pop,fresult,Pl,pLsize,vTsize,vCsize,vOsize)
%%pop  是swarmSize*N，矩阵
%%fresult 是SwarmSize*1 向量，表示每个粒子的适应值
%%Pl   是SwarmSize*1 向量，表示每个粒子的学习概率
%pLsize   快递柜的个数
%vTsize   必须访问的客户的个数
%vCsize   必须覆盖的客户的个数
%vOsize   可选的客户的个数


	[popsize,dim] = size(pop);
	if dim ~= 1+pLsize+vTsize+vCsize+vOsize
		error('Ugly error!dim ~= 1+pLsize+vTsize+vCsize+vOsize');
	end
	SwarmSize = popsize;
	
	%只需要对Vc和Vo的客户进行进化crossover
	subpop = pop(:,1+pLsize+vTsize+1:end);
	[popsize,n] = size(subpop);
	if n ~= vCsize+vOsize
		error('Ugly error!n ~= vCsize+vOsize');
	end
	
	
	for i=1:popsize % Updating learning examplers for group1; 
		fri_best(i,:) = i*ones(1,n);
		friend1 = ceil(popsize*rand(1,n));
		friend2 = ceil(popsize*rand(1,n));
		friend  = (fresult(friend1)<fresult(friend2))'.*friend1...
		+(fresult(friend1)>=fresult(friend2))'.*friend2;
		%1*n的学习样本下标矩阵
		
		toss = ceil(rand(1,n)-Pl(i));
		%%toss都是1，则都是大于pl的，则是表示不像别人学习，只是保留自己
		if toss==ones(1,n)
			temp_index=randperm(n);
			toss(1,temp_index(1))=0;%必须至少有一个向别人学习
			clear temp_index;
		end

		%toss == 0（rand<pl）就向别人学习，否则toss ==1（rand>pl）就是向自己学习
		fri_best(i,:)=(1-toss).*friend+toss.*fri_best(i,:);
		for d=1:n
			ui(i,d)=subpop(fri_best(i,d),d);
		end
	end
	
	
	
		
	pop(:,1+pLsize+vTsize+1:end)=ui;
	
	%修复每一个解，主要是针对PL的，根据上面的选择情况
	for j = 1: SwarmSize  
			
			pop(j,1+1:1+pLsize) = -1;%以防万一，再次置为-1
			Coveredbyi = pop(j,1+pLsize+vTsize+1:end);%所有的覆盖的和可选的客户的选择情况
			Cset =  unique(Coveredbyi);%独一无二的值
			Cset(Cset==0)=[];%去掉0
			if ~isempty(Cset)
				pop(j,Cset) = 0;
			end
	end