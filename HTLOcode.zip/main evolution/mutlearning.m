function [ pop ]= mutlearning(pop,CoverM,rg,pLsize,vTsize,vCsize,vOsize)
%pop     可以是 1*N；亦可以是全体swarmsize
%CoverM, 覆盖矩阵，N*N
%rg     是变异概率，是个标量，scalar 不是向量
%pLsize   快递柜的个数
%vTsize   必须访问的客户的个数
%vCsize   必须覆盖的客户的个数
%vOsize   可选的客户的个数


	[SwarmSize N] = size(pop);
	if 1+pLsize+vTsize+vCsize+vOsize ~= N
		error('Ugly error!!!'); 
	end
	
	
		
	%对必须覆盖的客户进行随机选取
	for i = 1+pLsize+vTsize+1:1+pLsize+vTsize+vCsize
			
		Stemp = CoverM( 1+1:1+pLsize,i);%覆盖客户i的所有PL节点
		S = find(Stemp==1);
		S = S+1;%因为depot编码1，占一个；应为PL编码从2开始，都需要加1
		Ssize = length(S);
		if Ssize == 0
			error('Ugly error!!! should be visited why covered?');
		end
		for j = 1: SwarmSize
			if rand < rg %变异概率
				selectedSindx = randperm(Ssize,1);
				pop(j,i) = S(selectedSindx); 
			end
		end
		
	end


	%对可选的客户进行随机选取
	for i = 1+pLsize+vTsize+vCsize+1:1+pLsize+vTsize+vCsize+vOsize
		
		Stemp = CoverM( 1+1:1+pLsize,i);%覆盖客户i的所有PL节点
		S = find(Stemp==1);
		S = S+1;%因为depot编码1，占一个；应为PL编码从2开始，都需要加1
		Ssize = length(S);
		if Ssize == 0
			error('Ugly error!!! should be visited why to be optional?');
		end
		
		for j = 1: SwarmSize  
			
			if rand < rg
				if rand < 0.5   %我觉得应该是visited然后再是covered，选谁cover它
					pop(j,i) = 0;
				else	
					selectedSindx = randperm(Ssize,1);
					pop(j,i) = S(selectedSindx); 
				end
			end	
			
		end
		
	end
	
	%修复每一个解，主要是针对PL的，根据上面的选择情况
	for j = 1: SwarmSize  
			
			pop(j,1+1:1+pLsize) = -1;%以防万一，再次置为-1
			Coveredbyi = pop(j,1+pLsize+vTsize+1:end);%所有的覆盖的和可选的客户的选择情况
			Cset =  unique(Coveredbyi);%独一无二的值
			Cset(Cset==0)=[];%去掉0
			if ~isempty(Cset)
				pop(j,Cset) = 0;
			end
	end