function [fxmin, xmin,xminsecond,Swarm,history]= HTLO() 
	
	
	
	%%%%%%%%%待解决的问题%%%%%%%%%%%%%%%%%%%%%
	CL = 7;
	alpha = 0.5;
	beta = 0.25;
	data = load ('ts225.tsp'); %%%load 数据集
	data = data(:,[2,3]);
	[newdata,PB,CoverM,pLsize,vTsize,vCsize,vOsize]  ...
	    = generateCoverdata(data,CL,alpha,beta);
		
	
	
	Dim  = size(data,1);
	SwarmSize = 50;
	
	global ci;
	theta = 0.25;
    ci = theta*629/Dim;
	
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
	
	%群大小和维度
	num_g = SwarmSize;
	dimension = Dim;
	
	%初始化pop
	[ pop ]= initPop(SwarmSize,CoverM,PB,pLsize,vTsize,vCsize,vOsize);
	
	%运行次数统计
	FEs = 0;
	Max_FEs = Dim *10000;
	
	%保存当前粒子的解的大小
	result = zeros(num_g,1); 
	secondlastgbest = cell(num_g,1);
	f2eval = 'calObjfunc';%不同的目标函数
	
	for i=1:num_g
		[result(i),secondlastgbest{i}]= feval(f2eval,pop(i,:),PB,pLsize);
		FEs = FEs + 1;
	end
	
	
	%种群的大小，exploration和exploitation群
	%exploitation群种群的大小
	num_g2 = num_g;
	%num_g2 = ceil(num_g*1/5);
	%num_g2 = num_g;
	%exploration群种群的大小
	num_g1 = num_g - num_g2;
	

	%取全局最优解，保存：solution及目标值
	global gbest_val;
	gbest_val = inf;
	[gbest_val,g_index] = min(result);
	global gbest_pop;
	gbest_pop = pop(g_index,:);
	global gbest_secondlastgbest;
	gbest_secondlastgbest = secondlastgbest{g_index};
	bestUpdateFlag = 1;%最优解是否更新
	
	global MaxOperators;
	MaxOperators = 4;
	global wOperators;
	wOperators = ones(1,MaxOperators); % weights of the operators
	global OperatorUseTimes;
	OperatorUseTimes = zeros(1,MaxOperators);%The number of times the operator has been used
	global OperatorScore;
	OperatorScore = ones(1,MaxOperators);%the score of operators
	global rho;
	rho = 0.6;
	
	iter = 1;
	Max_Iters = 1000;
	obj_func_slope=zeros(num_g,1);
	globalobj_func_slope = 0;
	maxcount = 100;
	Interval = 3;%显示𝑒𝑟
	
	history = [0, gbest_val];
	
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%                  THE  HCLMPSO  LOOP                      %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	while  iter <=Max_Iters && FEs <= Max_FEs
		
		rg = 0.2+((0.5-0.2)*iter)/Max_Iters;
		
		
		%%% group 1进化%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		%%%%%
		if num_g1 ~= 0
			ranki = zeros(1,num_g1);
			[dummy,rankidx] = sort(result(1:num_g1));
			ranki(rankidx) = 1:num_g1;
			Pl = 0.05+((0.1-0.05)*ranki)/num_g1;
			
			[pop_g1]= CLSlearning(pop(1:num_g1,:),result(1:num_g1),Pl,pLsize,vTsize,vCsize,vOsize);
		else
			pop_g1 = [];
		end
		
		%%% group 1进化%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		
		
		%%% group 2进化%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		if num_g2 ~= 0
			rankj = zeros(1,num_g2);
			[dummy,rankidx] = sort(result(num_g1+1:num_g));
			rankj(rankidx) = 1:num_g2;
			Pt = 0.05+((0.1-0.05)*rankj)/num_g2;
			
			[pop_g2]= TSlearning(pop(num_g1+1:end,:),Pt,gbest_pop,pLsize,vTsize,vCsize,vOsize);
		else
			pop_g2 = [];
		end
		%%% group 2进化%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		
		%%%%%%%%%%%% whole group，子代%%%%%%%%%%%%%
        newpop=[pop_g1;pop_g2];
		%%%%%%%%%%%% whole group，子代%%%%%%%%%%%%%
		
		
		
		%%%%%%population management%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		% Evaluate fitness
        temppop = pop;
		tempresult = result;
		tempsecondlastgbest = secondlastgbest;
		
		for i=1:num_g 
		
            [newresult(i),newsecondlastgbest{i}]= ...
				feval(f2eval,newpop(i,:),PB,pLsize);
			FEs = FEs +1;
			
            
			
 		    if  newresult(i) < result(i) % update pop and result
                %需要赋值
                obj_func_slope(i)=0;
				
				pop(i,:)  = newpop(i,:);   
				result(i) = newresult(i);
				secondlastgbest{i} = newsecondlastgbest{i};
				
				if  newresult(i) < gbest_val % update gbest value and postion
					gbest_pop = newpop(i,:); 
					gbest_secondlastgbest = newsecondlastgbest{i};
					gbest_val = newresult(i);
					bestUpdateFlag = 1;
				end  
				
            else
                obj_func_slope(i)=obj_func_slope(i)+1;
            end

			
			
		end
		
	%%%%%%Keep diversity of group1%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	%	[dummy,idxresult] = sort(tempresult(1:num_g1));
	%	[dummy,idxnewresult] = sort(result(1:num_g1));
		
	%	pop(idxnewresult(end-E+1:end),:) = temppop(idxresult(1:E),:);
	%	result(idxnewresult(end-E+1:end)) = tempresult(idxresult(1:E));
	%	for k = 1:E
	%		secondlastgbest{idxnewresult(end-E+k)} = ...
	%			tempsecondlastgbest{idxresult(k)};
	%	end		
	%%%%%%population management%%%%%%%%%%%%%%%%%%%%%%%%%%%%	
		
		
		
		if num_g1 ~= 0
			for i=1:num_g1 % updateding exampler for group 1
				if obj_func_slope(i) > 10
					[ pop(i,:) ]= mutlearning(pop(i,:),CoverM,rg,pLsize,vTsize,vCsize,vOsize);
					[result(i),secondlastgbest{i}]= feval(f2eval,pop(i,:),PB,pLsize);
					FEs = FEs + 1;
					%需要重新计算
					
					obj_func_slope(i)=0;
				end
			end % updating exampler for group 1
		end		
		
		if num_g2 ~= 0
			for i=num_g1+1:num_g % Updateding examplers for; group 2
				if obj_func_slope(i) > 10
					[ pop(i,:) ]= mutlearning(pop(i,:),CoverM,rg,pLsize,vTsize,vCsize,vOsize);
					[result(i),secondlastgbest{i}]= feval(f2eval,pop(i,:),PB,pLsize);
					FEs = FEs + 1;
					%需要重新计算
					obj_func_slope(i)=0;
				end
			end
		end
		
		history((size(history,1)+1), :) = [iter, gbest_val];
		
		
		%显示重新计算，
		if (rem(iter, Interval) == 0)
            fprintf('HTLO\t\t\t%4d\t\t\t%.5g\t\t\t%5d\n', iter, gbest_val, FEs);
        end 
		
		%有更新是否按照rand执行localsearch
		if bestUpdateFlag == 1
			globalobj_func_slope = 0;
			bestUpdateFlag = 0;
		else
			globalobj_func_slope = globalobj_func_slope+1;
		end	
		
		if globalobj_func_slope  > 10000000000
			disp('local search!');
			tempgbest_val =  gbest_val ;
			localsearchHTLO(gbest_pop,gbest_val,CoverM,PB,...
			  pLsize,vTsize,vCsize,vOsize,maxcount);
			if tempgbest_val > gbest_val
				disp('localsearch  updates global best!!');
			end
			bestUpdateFlag = 0;
			globalobj_func_slope = 0;
		end
		
		iter = iter+1;
	end
	
	%%最终输出最优解及当前种群
    xmin = gbest_pop;
	xminsecond = gbest_secondlastgbest;
    fxmin = gbest_val;
    Swarm = pop;	